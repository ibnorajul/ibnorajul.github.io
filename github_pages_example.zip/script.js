function sayHello() {
  alert("Hello from GitHub Pages!");
}